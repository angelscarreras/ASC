import React, { useState } from 'react';
import { PlusCircle, Calculator, Trash2 } from 'lucide-react';
import { Ingredient, NutritionalInfo } from '../types';

export default function RecipeCalculator() {
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [newIngredient, setNewIngredient] = useState<Partial<Ingredient>>({});
  const [totalNutrition, setTotalNutrition] = useState<NutritionalInfo>({
    calories: 0,
    protein: 0,
    carbs: 0,
    fat: 0,
  });

  const addIngredient = () => {
    if (newIngredient.name && newIngredient.amount) {
      const ingredient = {
        ...newIngredient,
        calories: newIngredient.calories || 0,
        protein: newIngredient.protein || 0,
        carbs: newIngredient.carbs || 0,
        fat: newIngredient.fat || 0,
      } as Ingredient;
      
      setIngredients([...ingredients, ingredient]);
      setNewIngredient({});
      calculateTotalNutrition([...ingredients, ingredient]);
    }
  };

  const calculateTotalNutrition = (ingredientsList: Ingredient[]) => {
    const totals = ingredientsList.reduce(
      (acc, curr) => ({
        calories: acc.calories + curr.calories,
        protein: acc.protein + curr.protein,
        carbs: acc.carbs + curr.carbs,
        fat: acc.fat + curr.fat,
      }),
      { calories: 0, protein: 0, carbs: 0, fat: 0 }
    );
    setTotalNutrition(totals);
  };

  const removeIngredient = (index: number) => {
    const newIngredients = ingredients.filter((_, i) => i !== index);
    setIngredients(newIngredients);
    calculateTotalNutrition(newIngredients);
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold mb-6">Recipe Nutrition Calculator</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h3 className="text-xl font-semibold">Add Ingredients</h3>
          <div className="space-y-3">
            <input
              type="text"
              placeholder="Ingredient name"
              className="w-full p-2 border rounded"
              value={newIngredient.name || ''}
              onChange={(e) => setNewIngredient({ ...newIngredient, name: e.target.value })}
            />
            <div className="grid grid-cols-2 gap-2">
              <input
                type="number"
                placeholder="Amount"
                className="p-2 border rounded"
                value={newIngredient.amount || ''}
                onChange={(e) => setNewIngredient({ ...newIngredient, amount: Number(e.target.value) })}
              />
              <input
                type="text"
                placeholder="Unit"
                className="p-2 border rounded"
                value={newIngredient.unit || ''}
                onChange={(e) => setNewIngredient({ ...newIngredient, unit: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="number"
                placeholder="Calories"
                className="p-2 border rounded"
                value={newIngredient.calories || ''}
                onChange={(e) => setNewIngredient({ ...newIngredient, calories: Number(e.target.value) })}
              />
              <input
                type="number"
                placeholder="Protein (g)"
                className="p-2 border rounded"
                value={newIngredient.protein || ''}
                onChange={(e) => setNewIngredient({ ...newIngredient, protein: Number(e.target.value) })}
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="number"
                placeholder="Carbs (g)"
                className="p-2 border rounded"
                value={newIngredient.carbs || ''}
                onChange={(e) => setNewIngredient({ ...newIngredient, carbs: Number(e.target.value) })}
              />
              <input
                type="number"
                placeholder="Fat (g)"
                className="p-2 border rounded"
                value={newIngredient.fat || ''}
                onChange={(e) => setNewIngredient({ ...newIngredient, fat: Number(e.target.value) })}
              />
            </div>
            <button
              onClick={addIngredient}
              className="w-full bg-blue-600 text-white p-2 rounded flex items-center justify-center gap-2 hover:bg-blue-700"
            >
              <PlusCircle size={20} /> Add Ingredient
            </button>
          </div>
        </div>

        <div>
          <h3 className="text-xl font-semibold mb-4">Ingredients List</h3>
          <div className="space-y-2">
            {ingredients.map((ingredient, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                <div>
                  <span className="font-medium">{ingredient.name}</span>
                  <span className="text-gray-600 ml-2">
                    ({ingredient.amount} {ingredient.unit})
                  </span>
                </div>
                <button
                  onClick={() => removeIngredient(index)}
                  className="text-red-500 hover:text-red-700"
                >
                  <Trash2 size={20} />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-8 p-4 bg-gray-50 rounded-lg">
        <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
          <Calculator size={24} />
          Total Nutritional Information
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-3 bg-white rounded shadow">
            <div className="text-gray-600">Calories</div>
            <div className="text-2xl font-bold">{totalNutrition.calories}</div>
          </div>
          <div className="p-3 bg-white rounded shadow">
            <div className="text-gray-600">Protein</div>
            <div className="text-2xl font-bold">{totalNutrition.protein}g</div>
          </div>
          <div className="p-3 bg-white rounded shadow">
            <div className="text-gray-600">Carbs</div>
            <div className="text-2xl font-bold">{totalNutrition.carbs}g</div>
          </div>
          <div className="p-3 bg-white rounded shadow">
            <div className="text-gray-600">Fat</div>
            <div className="text-2xl font-bold">{totalNutrition.fat}g</div>
          </div>
        </div>
      </div>
    </div>
  );
}