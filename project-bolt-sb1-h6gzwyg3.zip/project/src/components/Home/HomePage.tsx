import React from 'react';
import { Link } from 'react-router-dom';
import { Calculator, MessageSquare } from 'lucide-react';

export function HomePage() {
  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-50 flex items-center justify-center">
      <div className="max-w-4xl mx-auto p-8 text-center">
        <h1 className="text-4xl font-bold mb-6">Welcome to NutriPlanner</h1>
        <p className="text-xl text-gray-600 mb-8">
          Your comprehensive solution for diet planning and nutrition consultation
        </p>
        <div className="grid md:grid-cols-2 gap-6">
          <Link
            to="/calculator"
            className="p-6 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow"
          >
            <Calculator size={48} className="mx-auto mb-4 text-blue-600" />
            <h2 className="text-2xl font-semibold mb-2">Recipe Calculator</h2>
            <p className="text-gray-600">
              Calculate nutritional information for your recipes
            </p>
          </Link>
          <Link
            to="/chat"
            className="p-6 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow"
          >
            <MessageSquare size={48} className="mx-auto mb-4 text-blue-600" />
            <h2 className="text-2xl font-semibold mb-2">Nutrition Chat</h2>
            <p className="text-gray-600">
              Get expert nutrition advice powered by AI
            </p>
          </Link>
        </div>
      </div>
    </div>
  );
}