import React from 'react';
import { Calculator } from 'lucide-react';
import { NutritionalInfo } from '../../types';

interface NutritionSummaryProps {
  nutrition: NutritionalInfo;
}

export function NutritionSummary({ nutrition }: NutritionSummaryProps) {
  return (
    <div className="mt-8 p-4 bg-gray-50 rounded-lg">
      <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
        <Calculator size={24} />
        Total Nutritional Information
      </h3>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-3 bg-white rounded shadow">
          <div className="text-gray-600">Calories</div>
          <div className="text-2xl font-bold">{nutrition.calories}</div>
        </div>
        <div className="p-3 bg-white rounded shadow">
          <div className="text-gray-600">Protein</div>
          <div className="text-2xl font-bold">{nutrition.protein}g</div>
        </div>
        <div className="p-3 bg-white rounded shadow">
          <div className="text-gray-600">Carbs</div>
          <div className="text-2xl font-bold">{nutrition.carbs}g</div>
        </div>
        <div className="p-3 bg-white rounded shadow">
          <div className="text-gray-600">Fat</div>
          <div className="text-2xl font-bold">{nutrition.fat}g</div>
        </div>
      </div>
    </div>
  );
}