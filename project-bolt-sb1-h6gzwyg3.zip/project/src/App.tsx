import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Navigation } from './components/Navigation/Navigation';
import { HomePage } from './components/Home/HomePage';
import { RecipeCalculator } from './components/Calculator/RecipeCalculator';
import { NutritionChat } from './components/Chat/NutritionChat';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <main className="container mx-auto py-8 px-4">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/calculator" element={<RecipeCalculator />} />
            <Route path="/chat" element={<NutritionChat />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;