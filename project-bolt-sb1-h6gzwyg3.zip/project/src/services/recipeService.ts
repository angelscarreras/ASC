import OpenAI from 'openai';
import { Recipe, NutritionalInfo } from '../types';

const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true
});

const STORAGE_KEY = 'saved_recipes';

export async function analyzeRecipe(ingredients: string): Promise<{ nutritionalInfo: NutritionalInfo, instructions: string }> {
  try {
    const completion = await openai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: `You are a precise nutrition calculator. For the given recipe ingredients, calculate exact nutritional values and provide clear instructions. Follow these rules:

1. Analyze each ingredient's quantity and nutritional content carefully
2. Calculate total values for the entire recipe
3. Consider cooking methods that might affect nutritional content
4. Account for any liquid evaporation or absorption
5. Use standard USDA nutritional database values as reference
6. Round calculations to 1 decimal place
7. Include detailed step-by-step instructions
8. Format response in JSON with exact structure:
{
  "nutritionalInfo": {
    "calories": number,
    "protein": number,
    "carbs": number,
    "fat": number
  },
  "instructions": "Detailed numbered steps"
}`
        },
        {
          role: 'user',
          content: `Calculate precise nutritional information and provide cooking instructions for these ingredients:\n${ingredients}`
        }
      ],
      model: 'gpt-3.5-turbo',
      response_format: { type: "json_object" }
    });

    const response = JSON.parse(completion.choices[0].message.content);
    
    // Validate and clean the response
    const nutritionalInfo: NutritionalInfo = {
      calories: Math.round(response.nutritionalInfo.calories * 10) / 10,
      protein: Math.round(response.nutritionalInfo.protein * 10) / 10,
      carbs: Math.round(response.nutritionalInfo.carbs * 10) / 10,
      fat: Math.round(response.nutritionalInfo.fat * 10) / 10
    };

    return {
      nutritionalInfo,
      instructions: response.instructions
    };
  } catch (error) {
    console.error('OpenAI API Error:', error);
    throw new Error('Failed to analyze recipe');
  }
}

export function saveRecipe(recipe: Recipe): void {
  const savedRecipes = getSavedRecipes();
  savedRecipes.push(recipe);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(savedRecipes));
}

export function getSavedRecipes(): Recipe[] {
  const saved = localStorage.getItem(STORAGE_KEY);
  return saved ? JSON.parse(saved) : [];
}

export function deleteRecipe(id: string): void {
  const savedRecipes = getSavedRecipes();
  const updatedRecipes = savedRecipes.filter(recipe => recipe.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedRecipes));
}