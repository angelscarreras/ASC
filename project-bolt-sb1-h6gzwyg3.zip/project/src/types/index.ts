export interface Recipe {
  id: string;
  name: string;
  ingredients: string;
  instructions: string;
  nutritionalInfo: NutritionalInfo;
  servings: number;
  preparationTime: number;
  createdAt: string;
}

export interface NutritionalInfo {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export interface SavedRecipe extends Recipe {
  id: string;
}