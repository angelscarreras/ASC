import React, { useState, useEffect } from 'react';
import { Recipe, NutritionalInfo } from '../../types';
import { analyzeRecipe, saveRecipe, getSavedRecipes, deleteRecipe } from '../../services/recipeService';
import { Book, Save, Trash2, Clock, Users, AlertCircle } from 'lucide-react';

export function RecipeCalculator() {
  const [recipe, setRecipe] = useState<Partial<Recipe>>({
    name: '',
    ingredients: '',
    instructions: '',
    servings: 1,
    preparationTime: 30,
    nutritionalInfo: {
      calories: 0,
      protein: 0,
      carbs: 0,
      fat: 0
    }
  });
  const [savedRecipes, setSavedRecipes] = useState<Recipe[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setSavedRecipes(getSavedRecipes());
  }, []);

  const validateIngredients = (ingredients: string): boolean => {
    const lines = ingredients.split('\n');
    for (const line of lines) {
      if (line.trim() && !line.match(/^\d+(\.\d+)?\s*(g|kg|ml|l|cup|cups|tbsp|tsp|oz|pound|pounds|piece|pieces)\s+\w+/i)) {
        return false;
      }
    }
    return true;
  };

  const handleAnalyze = async () => {
    if (!recipe.ingredients || !recipe.name) {
      setError('Please provide both recipe name and ingredients');
      return;
    }

    if (!validateIngredients(recipe.ingredients)) {
      setError('Please format ingredients with quantities and units (e.g., "2 cups flour" or "100g sugar")');
      return;
    }

    setIsAnalyzing(true);
    setError(null);

    try {
      const analysis = await analyzeRecipe(recipe.ingredients);
      
      // Calculate per serving values
      const servings = recipe.servings || 1;
      const perServingNutrition: NutritionalInfo = {
        calories: Math.round((analysis.nutritionalInfo.calories / servings) * 10) / 10,
        protein: Math.round((analysis.nutritionalInfo.protein / servings) * 10) / 10,
        carbs: Math.round((analysis.nutritionalInfo.carbs / servings) * 10) / 10,
        fat: Math.round((analysis.nutritionalInfo.fat / servings) * 10) / 10
      };

      setRecipe(prev => ({
        ...prev,
        nutritionalInfo: perServingNutrition,
        instructions: analysis.instructions
      }));
    } catch (err) {
      setError('Failed to analyze recipe. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSave = () => {
    if (!recipe.name || !recipe.ingredients || !recipe.nutritionalInfo) {
      setError('Please analyze the recipe before saving');
      return;
    }

    const newRecipe: Recipe = {
      ...recipe as Recipe,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    };

    saveRecipe(newRecipe);
    setSavedRecipes(getSavedRecipes());
    setError('Recipe saved successfully!');
  };

  const handleDelete = (id: string) => {
    deleteRecipe(id);
    setSavedRecipes(getSavedRecipes());
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
        <h2 className="text-2xl font-bold mb-6">Recipe Analyzer</h2>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Recipe Name
            </label>
            <input
              type="text"
              value={recipe.name}
              onChange={(e) => setRecipe(prev => ({ ...prev, name: e.target.value }))}
              className="w-full p-2 border rounded"
              placeholder="Enter recipe name"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <Users className="inline-block mr-1" size={16} />
                Servings
              </label>
              <input
                type="number"
                value={recipe.servings}
                onChange={(e) => setRecipe(prev => ({ ...prev, servings: Number(e.target.value) }))}
                className="w-full p-2 border rounded"
                min="1"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <Clock className="inline-block mr-1" size={16} />
                Preparation Time (minutes)
              </label>
              <input
                type="number"
                value={recipe.preparationTime}
                onChange={(e) => setRecipe(prev => ({ ...prev, preparationTime: Number(e.target.value) }))}
                className="w-full p-2 border rounded"
                min="1"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Ingredients
            </label>
            <div className="mb-2 text-sm text-gray-600 flex items-center">
              <AlertCircle size={16} className="mr-1" />
              Enter each ingredient with quantity and unit (e.g., "2 cups flour" or "100g sugar")
            </div>
            <textarea
              value={recipe.ingredients}
              onChange={(e) => setRecipe(prev => ({ ...prev, ingredients: e.target.value }))}
              className="w-full p-2 border rounded h-32"
              placeholder="100g flour&#10;2 cups sugar&#10;3 tbsp butter"
            />
          </div>

          {error && (
            <div className={`p-3 rounded ${error.includes('success') ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
              {error}
            </div>
          )}

          <div className="flex gap-2">
            <button
              onClick={handleAnalyze}
              disabled={isAnalyzing}
              className="flex-1 bg-blue-600 text-white p-2 rounded flex items-center justify-center gap-2 hover:bg-blue-700 disabled:opacity-50"
            >
              <Book size={20} />
              {isAnalyzing ? 'Analyzing...' : 'Analyze Recipe'}
            </button>
            <button
              onClick={handleSave}
              className="flex-1 bg-green-600 text-white p-2 rounded flex items-center justify-center gap-2 hover:bg-green-700"
            >
              <Save size={20} />
              Save Recipe
            </button>
          </div>
        </div>

        {recipe.nutritionalInfo && recipe.nutritionalInfo.calories > 0 && (
          <div className="mt-6">
            <h3 className="text-xl font-semibold mb-4">Analysis Results (per serving)</h3>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="p-3 bg-gray-50 rounded shadow">
                <div className="text-gray-600">Calories</div>
                <div className="text-2xl font-bold">{recipe.nutritionalInfo.calories}</div>
              </div>
              <div className="p-3 bg-gray-50 rounded shadow">
                <div className="text-gray-600">Protein</div>
                <div className="text-2xl font-bold">{recipe.nutritionalInfo.protein}g</div>
              </div>
              <div className="p-3 bg-gray-50 rounded shadow">
                <div className="text-gray-600">Carbs</div>
                <div className="text-2xl font-bold">{recipe.nutritionalInfo.carbs}g</div>
              </div>
              <div className="p-3 bg-gray-50 rounded shadow">
                <div className="text-gray-600">Fat</div>
                <div className="text-2xl font-bold">{recipe.nutritionalInfo.fat}g</div>
              </div>
            </div>

            {recipe.instructions && (
              <div className="bg-gray-50 p-4 rounded">
                <h4 className="font-semibold mb-2">Instructions:</h4>
                <div className="whitespace-pre-line">{recipe.instructions}</div>
              </div>
            )}
          </div>
        )}
      </div>

      {savedRecipes.length > 0 && (
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h3 className="text-xl font-semibold mb-4">Saved Recipes</h3>
          <div className="space-y-4">
            {savedRecipes.map((saved) => (
              <div key={saved.id} className="border rounded p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-semibold">{saved.name}</h4>
                    <p className="text-sm text-gray-600">
                      <Users className="inline-block mr-1" size={16} />
                      {saved.servings} servings
                      <Clock className="inline-block ml-4 mr-1" size={16} />
                      {saved.preparationTime} mins
                    </p>
                  </div>
                  <button
                    onClick={() => handleDelete(saved.id)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <Trash2 size={20} />
                  </button>
                </div>
                <div className="mt-2">
                  <div className="text-sm text-gray-600">Nutritional Info (per serving):</div>
                  <div className="text-sm">
                    {saved.nutritionalInfo.calories} cal | 
                    {saved.nutritionalInfo.protein}g protein | 
                    {saved.nutritionalInfo.carbs}g carbs | 
                    {saved.nutritionalInfo.fat}g fat
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}