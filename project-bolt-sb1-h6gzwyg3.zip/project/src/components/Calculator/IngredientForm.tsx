import React from 'react';
import { PlusCircle } from 'lucide-react';
import { Ingredient } from '../../types';

interface IngredientFormProps {
  newIngredient: Partial<Ingredient>;
  setNewIngredient: (ingredient: Partial<Ingredient>) => void;
  onAdd: () => void;
}

export function IngredientForm({ newIngredient, setNewIngredient, onAdd }: IngredientFormProps) {
  return (
    <div className="space-y-4">
      <h3 className="text-xl font-semibold">Add Ingredients</h3>
      <div className="space-y-3">
        <input
          type="text"
          placeholder="Ingredient name"
          className="w-full p-2 border rounded"
          value={newIngredient.name || ''}
          onChange={(e) => setNewIngredient({ ...newIngredient, name: e.target.value })}
        />
        <div className="grid grid-cols-2 gap-2">
          <input
            type="number"
            placeholder="Amount"
            className="p-2 border rounded"
            value={newIngredient.amount || ''}
            onChange={(e) => setNewIngredient({ ...newIngredient, amount: Number(e.target.value) })}
          />
          <input
            type="text"
            placeholder="Unit"
            className="p-2 border rounded"
            value={newIngredient.unit || ''}
            onChange={(e) => setNewIngredient({ ...newIngredient, unit: e.target.value })}
          />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <input
            type="number"
            placeholder="Calories"
            className="p-2 border rounded"
            value={newIngredient.calories || ''}
            onChange={(e) => setNewIngredient({ ...newIngredient, calories: Number(e.target.value) })}
          />
          <input
            type="number"
            placeholder="Protein (g)"
            className="p-2 border rounded"
            value={newIngredient.protein || ''}
            onChange={(e) => setNewIngredient({ ...newIngredient, protein: Number(e.target.value) })}
          />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <input
            type="number"
            placeholder="Carbs (g)"
            className="p-2 border rounded"
            value={newIngredient.carbs || ''}
            onChange={(e) => setNewIngredient({ ...newIngredient, carbs: Number(e.target.value) })}
          />
          <input
            type="number"
            placeholder="Fat (g)"
            className="p-2 border rounded"
            value={newIngredient.fat || ''}
            onChange={(e) => setNewIngredient({ ...newIngredient, fat: Number(e.target.value) })}
          />
        </div>
        <button
          onClick={onAdd}
          className="w-full bg-blue-600 text-white p-2 rounded flex items-center justify-center gap-2 hover:bg-blue-700"
        >
          <PlusCircle size={20} /> Add Ingredient
        </button>
      </div>
    </div>
  );
}