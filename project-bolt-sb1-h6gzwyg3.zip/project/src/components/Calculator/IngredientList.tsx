import React from 'react';
import { Trash2 } from 'lucide-react';
import { Ingredient } from '../../types';

interface IngredientListProps {
  ingredients: Ingredient[];
  onRemove: (index: number) => void;
}

export function IngredientList({ ingredients, onRemove }: IngredientListProps) {
  return (
    <div>
      <h3 className="text-xl font-semibold mb-4">Ingredients List</h3>
      <div className="space-y-2">
        {ingredients.map((ingredient, index) => (
          <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded">
            <div>
              <span className="font-medium">{ingredient.name}</span>
              <span className="text-gray-600 ml-2">
                ({ingredient.amount} {ingredient.unit})
              </span>
            </div>
            <button
              onClick={() => onRemove(index)}
              className="text-red-500 hover:text-red-700"
            >
              <Trash2 size={20} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}